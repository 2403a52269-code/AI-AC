const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');

const {
    addSport,
    getSports,
    registerStudentForSport,
    updateSport,
    deleteSport
} = require('../controllers/sportController');

router.post('/add', auth, addSport);
router.get('/all', auth, getSports);
router.post('/register', auth, registerStudentForSport);
router.put('/update/:id', auth, updateSport);
router.delete('/delete/:id', auth, deleteSport);

module.exports = router;
