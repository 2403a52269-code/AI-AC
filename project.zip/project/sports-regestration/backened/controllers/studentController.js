const Student = require('../models/Student');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.registerStudent = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        let student = await Student.findOne({ email });
        if (student)
            return res.status(400).json({ msg: 'Student already exists' });

        const hashedPassword = await bcrypt.hash(password, 10);

        student = new Student({ name, email, password: hashedPassword });
        await student.save();

        const payload = { id: student._id, role: 'student' };

        jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
            res.json({ token });
        });
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
};

exports.loginStudent = async (req, res) => {
    const { email, password } = req.body;
    try {
        const student = await Student.findOne({ email });
        if (!student)
            return res.status(400).json({ msg: 'Invalid credentials' });

        const isMatch = await bcrypt.compare(password, student.password);
        if (!isMatch)
            return res.status(400).json({ msg: 'Invalid credentials' });

        const payload = { id: student._id, role: 'student' };

        jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
            res.json({ token });
        });
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
};
