const Sport = require('../models/Sport');
const Student = require('../models/Student');

// =============================
// ADD NEW SPORT (Faculty)
// =============================
exports.addSport = async (req, res) => {
    const { title, description, date, fee } = req.body;

    try {
        const sport = new Sport({ title, description, date, fee });
        await sport.save();
        res.json({ msg: 'Sport added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Server error' });
    }
};

// =============================
// GET ALL SPORTS (Student/Faculty)
// =============================
exports.getSports = async (req, res) => {
    try {
        const sports = await Sport.find();
        res.json(sports);
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
};

// =============================
// REGISTER STUDENT FOR SPORT
// =============================
exports.registerStudentForSport = async (req, res) => {
    const { sportId } = req.body;
    console.log('RegisterStudentForSport called. body:', req.body);
    console.log('Request headers x-auth-token:', req.header('x-auth-token') ? '[present]' : '[missing]');
    console.log('Decoded user from auth middleware:', req.user);

    const studentId = req.user && (req.user.id || (req.user._id)); // from JWT

    if (!studentId) {
        console.error('No studentId found on req.user');
        return res.status(401).json({ msg: 'Unauthorized: invalid token payload' });
    }

    try {
        const sport = await Sport.findById(sportId);
        const student = await Student.findById(studentId);

        console.log('Found sport:', !!sport, 'Found student:', !!student);

        if (!sport) return res.status(404).json({ msg: 'Sport not found' });

        // prevent double registration
        if (sport.registeredStudents.includes(studentId)) {
            return res.status(400).json({ msg: 'Already registered' });
        }

        sport.registeredStudents.push(studentId);
        student.registeredSports.push(sportId);

        await sport.save();
        await student.save();

        res.json({ msg: 'Registration successful' });
    } catch (err) {
        console.error('RegisterStudentForSport Error:', err && err.stack ? err.stack : err);
        res.status(500).json({ msg: 'Server error' });
    }
};

// =============================
// UPDATE SPORT (Faculty)
// =============================
exports.updateSport = async (req, res) => {
    try {
        const updated = await Sport.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        if (!updated) return res.status(404).json({ msg: 'Sport not found' });

        res.json({ msg: 'Sport updated successfully', sport: updated });
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Server error' });
    }
};

// =============================
// DELETE SPORT (Faculty)
// =============================
exports.deleteSport = async (req, res) => {
    try {
        const deleted = await Sport.findByIdAndDelete(req.params.id);

        if (!deleted) return res.status(404).json({ msg: 'Sport not found' });

        res.json({ msg: 'Sport deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ msg: 'Server error' });
    }
};
