const Faculty = require('../models/Faculty');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.registerFaculty = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        let faculty = await Faculty.findOne({ email });
        if (faculty) return res.status(400).json({ msg: 'Faculty already exists' });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        faculty = new Faculty({ name, email, password: hashedPassword });
        await faculty.save();

        const token = jwt.sign({ id: faculty._id, role: 'faculty' }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
};

exports.loginFaculty = async (req, res) => {
    const { email, password } = req.body;
    try {
        const faculty = await Faculty.findOne({ email });
        if (!faculty) return res.status(400).json({ msg: 'Invalid Credentials' });

        const isMatch = await bcrypt.compare(password, faculty.password);
        if (!isMatch) return res.status(400).json({ msg: 'Invalid Credentials' });

        const token = jwt.sign({ id: faculty._id, role: 'faculty' }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (err) {
        res.status(500).json({ msg: 'Server error' });
    }
};
