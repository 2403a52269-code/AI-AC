const mongoose = require('mongoose');

const sportSchema = new mongoose.Schema({
    title: String,
    description: String,
    date: Date,
    fee: Number,
    registeredStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }]
});

module.exports = mongoose.model('Sport', sportSchema);
