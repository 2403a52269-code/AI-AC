let facultyToken = '';

// =======================
// REGISTER FACULTY
// =======================
async function registerFaculty() {
    const name = document.getElementById('facName').value;
    const email = document.getElementById('facEmail').value;
    const password = document.getElementById('facPassword').value;

    if(!name || !email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const res = await fetch('http://localhost:5000/api/faculty/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });

        const data = await res.json();
        if(res.ok) {
            facultyToken = data.token;
            alert('Faculty registered successfully');
            showDashboard();
        } else {
            alert(data.msg || 'Error registering');
        }
    } catch(err) {
        console.error('Register Faculty Error:', err);
        alert('Error connecting to server');
    }
}

// =======================
// LOGIN FACULTY
// =======================
async function loginFaculty() {
    const email = document.getElementById('facLoginEmail').value;
    const password = document.getElementById('facLoginPassword').value;

    if(!email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const res = await fetch('http://localhost:5000/api/faculty/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await res.json();
        if(res.ok) {
            facultyToken = data.token;
            alert('Login successful');
            showDashboard();
        } else {
            alert(data.msg || 'Error logging in');
        }
    } catch(err) {
        console.error('Login Faculty Error:', err);
        alert('Error connecting to server');
    }
}

// =======================
// SHOW DASHBOARD
// =======================
function showDashboard() {
    document.getElementById('facultyAuth').style.display = 'none';
    document.getElementById('facultyDashboard').style.display = 'block';
    fetchSports();
}

// =======================
// FETCH ALL SPORTS
// =======================
async function fetchSports() {
    try {
        const res = await fetch('http://localhost:5000/api/sport/all', {
            headers: { 'x-auth-token': facultyToken }
        });

        if(!res.ok) {
            alert('Failed to fetch sports');
            return;
        }

        const sports = await res.json();
        const list = document.getElementById('sportsList');
        list.innerHTML = '';

        if(sports.length === 0) {
            list.innerHTML = '<li>No sports available</li>';
            return;
        }

        sports.forEach(sport => {
            const li = document.createElement('li');
            li.innerHTML = `
                ${sport.title} - Fee: $${sport.fee} 
                <button onclick="deleteSport('${sport._id}')">Delete</button>
            `;
            list.appendChild(li);
        });
    } catch(err) {
        console.error('Fetch Sports Error:', err);
        alert('Error connecting to server');
    }
}

// =======================
// ADD NEW SPORT
// =======================
async function addSport() {
    const title = document.getElementById('sportTitle').value;
    const fee = document.getElementById('sportFee').value;

    if(!title || !fee) {
        alert('Please fill all fields');
        return;
    }

    try {
        const res = await fetch('http://localhost:5000/api/sport/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-auth-token': facultyToken
            },
            body: JSON.stringify({ title, fee })
        });

        const data = await res.json();
        if(res.ok) {
            alert(data.msg || 'Sport added successfully');
            document.getElementById('sportTitle').value = '';
            document.getElementById('sportFee').value = '';
            fetchSports();
        } else {
            alert(data.msg || 'Failed to add sport');
        }
    } catch(err) {
        console.error('Add Sport Error:', err);
        alert('Error connecting to server');
    }
}

// =======================
// DELETE SPORT
// =======================
async function deleteSport(sportId) {
    if(!confirm('Are you sure you want to delete this sport?')) return;

    try {
        const res = await fetch(`http://localhost:5000/api/sport/delete/${sportId}`, {
            method: 'DELETE',
            headers: { 'x-auth-token': facultyToken }
        });

        const data = await res.json();
        if(res.ok) {
            alert(data.msg || 'Sport deleted successfully');
            fetchSports();
        } else {
            alert(data.msg || 'Failed to delete sport');
        }
    } catch(err) {
        console.error('Delete Sport Error:', err);
        alert('Error connecting to server');
    }
}

// =======================
// LOGOUT FACULTY
// =======================
function logoutFaculty() {
    facultyToken = '';
    document.getElementById('facultyDashboard').style.display = 'none';
    document.getElementById('facultyAuth').style.display = 'block';
}
