let studentToken = "";

// =======================
// LOAD TOKEN ON PAGE LOAD
// =======================
window.onload = () => {
    const token = localStorage.getItem("studentToken");
    if (token) {
        studentToken = token;
        showDashboard();
    }
};

// =======================
// REGISTER STUDENT
// =======================
async function registerStudent() {
    const name = document.getElementById("stuName").value;
    const email = document.getElementById("stuEmail").value;
    const password = document.getElementById("stuPassword").value;

    if (!name || !email || !password) {
        alert("Please fill all fields");
        return;
    }

    try {
        const res = await fetch("http://localhost:5000/api/student/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password }),
        });

        const data = await res.json();

        if (res.ok && data.token) {
            studentToken = data.token;
            localStorage.setItem("studentToken", studentToken);
            alert("Registration successful");
            showDashboard();
        } else {
            alert(data.msg || "Registration failed");
        }
    } catch (err) {
        console.error("Register Error:", err);
        alert("Server connection error");
    }
}

// =======================
// LOGIN STUDENT
// =======================
async function loginStudent() {
    const email = document.getElementById("stuLoginEmail").value;
    const password = document.getElementById("stuLoginPassword").value;

    if (!email || !password) {
        alert("Please fill all fields");
        return;
    }

    try {
        const res = await fetch("http://localhost:5000/api/student/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
        });

        const data = await res.json();

        if (res.ok && data.token) {
            studentToken = data.token;
            localStorage.setItem("studentToken", studentToken);
            alert("Login successful");
            showDashboard();
        } else {
            alert(data.msg || "Invalid login");
        }
    } catch (err) {
        console.error("Login Error:", err);
        alert("Server connection error");
    }
}

// =======================
// SHOW DASHBOARD
// =======================
function showDashboard() {
    document.getElementById("studentAuth").style.display = "none";
    document.getElementById("studentDashboard").style.display = "block";
    fetchSports();
}

// =======================
// FETCH ALL SPORTS
// =======================
async function fetchSports() {
    try {
        const res = await fetch("http://localhost:5000/api/sport/all", {
            headers: { "x-auth-token": studentToken },
        });

        if (!res.ok) {
            alert("Failed to fetch sports");
            return;
        }

        const sports = await res.json();
        const list = document.getElementById("sportsList");
        list.innerHTML = "";

        if (!sports.length) {
            list.innerHTML = "<li>No sports available</li>";
            return;
        }

        sports.forEach((sport) => {
            const li = document.createElement("li");
            li.innerHTML = `
                ${sport.title} - Fee: ₹${sport.fee}
                <button onclick="registerSport('${sport._id}')">Register</button>
            `;
            list.appendChild(li);
        });
    } catch (err) {
        console.error("Fetch Sports Error:", err);
        alert("Server connection error");
    }
}

// =======================
// REGISTER FOR A SPORT
// =======================
async function registerSport(sportId) {
    try {
        const res = await fetch('http://localhost:5000/api/sport/register', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'x-auth-token': studentToken
            },
            body: JSON.stringify({ sportId }) // studentId comes from token in backend
        });

        // Determine response content type and parse accordingly
        const contentType = res.headers.get('content-type') || '';
        let data;
        if (contentType.includes('application/json')) {
            data = await res.json();
        } else {
            // fallback to text for non-JSON responses
            const text = await res.text();
            data = { msg: text };
        }

        if (res.ok) {
            alert(data.msg || 'Registered successfully');
            fetchSports(); // refresh list if needed
        } else {
            alert(data.msg || 'Failed to register');
        }
    } catch (err) {
        console.error('Register Sport Error:', err);
        alert('Error connecting to server. Make sure your backend is running at http://localhost:5000');
    }
}


// =======================
// LOGOUT STUDENT
// =======================
function logoutStudent() {
    studentToken = "";
    localStorage.removeItem("studentToken");
    document.getElementById("studentDashboard").style.display = "none";
    document.getElementById("studentAuth").style.display = "block";
}
